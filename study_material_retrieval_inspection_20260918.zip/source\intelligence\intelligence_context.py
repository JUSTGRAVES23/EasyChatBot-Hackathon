"""
Intelligence Context.

Provider-independent representation of external
information prepared for AI execution.

Architecture:

Research Agent
        |
        v
IntelligenceContext
        |
        v
AI Runtime integration
        |
        v
LLMRequest.context

The context must not expose provider-specific
implementation details to the application layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class IntelligenceSource:
    """
    Normalised external information source.
    """

    title: str
    url: str
    source: str
    content: str = ""

    def __post_init__(self) -> None:
        if not self.title.strip():
            raise ValueError(
                "Intelligence source title cannot be empty."
            )

        if not self.url.strip():
            raise ValueError(
                "Intelligence source URL cannot be empty."
            )

        if not self.source.strip():
            raise ValueError(
                "Intelligence source name cannot be empty."
            )


@dataclass(frozen=True, slots=True)
class IntelligenceContext:
    """
    Provider-independent intelligence context.

    Represents external information that may be supplied
    to an existing AI conversation.

    This object deliberately does not contain:
    - provider SDK objects
    - API credentials
    - model information
    - runtime state
    - persistence objects
    """

    query: str

    sources: tuple[IntelligenceSource, ...] = field(
        default_factory=tuple,
    )

    summary: str = ""

    def __post_init__(self) -> None:
        if not self.query.strip():
            raise ValueError(
                "Intelligence query cannot be empty."
            )

        if not isinstance(
            self.sources,
            tuple,
        ):
            raise ValueError(
                "Intelligence sources must be a tuple."
            )

        if not isinstance(
            self.summary,
            str,
        ):
            raise ValueError(
                "Intelligence summary must be a string."
            )

    @property
    def has_sources(self) -> bool:
        """
        Return whether external sources are available.
        """

        return bool(self.sources)

    @property
    def source_count(self) -> int:
        """
        Return the number of external sources.
        """

        return len(self.sources)

    @property
    def has_summary(self) -> bool:
        """
        Return whether a summary is available.
        """

        return bool(
            self.summary.strip()
        )

    def to_context_text(self) -> str:
        """
        Convert intelligence into a safe textual context.

        The result is suitable for eventual inclusion
        in an existing LLMRequest.context field.
        """

        sections: list[str] = [
            "LIVE INTELLIGENCE",
            f"Research query: {self.query.strip()}",
        ]

        if self.summary.strip():
            sections.extend(
                (
                    "",
                    "Summary:",
                    self.summary.strip(),
                )
            )

        if self.sources:
            sections.extend(
                (
                    "",
                    "Sources:",
                )
            )

            for index, source in enumerate(
                self.sources,
                start=1,
            ):
                sections.append(
                    f"{index}. {source.title}"
                )
                sections.append(
                    f"   URL: {source.url}"
                )
                sections.append(
                    f"   Source: {source.source}"
                )

                if source.content.strip():
                    sections.append(
                        f"   Content: {source.content.strip()}"
                    )

        return "\n".join(sections)